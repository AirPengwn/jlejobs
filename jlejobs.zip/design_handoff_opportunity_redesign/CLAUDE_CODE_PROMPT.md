# Claude Code prompt — Opportunity Dashboard redesign

Copy everything below the line into Claude Code, running inside your `jlejobs` repo with this `design_handoff_opportunity_redesign/` folder present.

---

You are working in the `jlejobs` repo — a single-user, static, vanilla HTML/CSS/JS PWA on GitHub Pages (no framework, no build step). Implement the Opportunities-tab redesign specified in `design_handoff_opportunity_redesign/README.md`. Read that README in full first, then open `design_handoff_opportunity_redesign/reference/Opportunity Dashboard Redesign.html` in your head as the visual source of truth (sections 01–05; the "Details" and "+N" toggles show the two key interactions).

**Edit these files in place — do NOT rewrite the app or introduce a framework:**
- `index.html` — viewport meta (`viewport-fit=cover`); compact left-aligned masthead; filter panel split into Refine + collapsible More.
- `assets/css/styles.css` — `:root` additions (normalized oklch accents + `--radius-sm`); restyle `.card*`; header rules + a `@media (max-width:640px)` mobile reflow with `env(safe-area-inset-*)`; filter + `.seg` segmented control.
- `assets/js/app.js` — rewrite `cardHTML()` to the collapsed face + `.r-drawer` (full detail) + expandable tags; add `.r-details` and `.r-tagmore` listeners in `wireCards()`; ensure existing action handlers `stopPropagation`. Keep `fitPct`, `commuteInfo`, `isNew`, `mayBeExpired`, sorting, filtering and sync logic intact.
- `sw.js` — bump the cache version and delete old caches on activate.

**Hard requirements (do not violate):**
1. **No information loss.** Everything currently on the card (status dropdown, notes, draft-outreach, full description, full metadata, every tag, apply + alt links) must remain reachable — collapsed onto the card face for triage, full set inside the in-card "Details" drawer. Wire the drawer's controls to the EXISTING handlers (`openOutreach`, `openDetail`, status/note persistence, `scheduleSync`).
2. **Wire to real data.** Render against `window.JOBS`, real `fitPct(j)` for the Fit anchor, real `commuteInfo`, `j.linkStatus`/`mayBeExpired` for the exception strip. Don't hardcode the sample values from the reference.
3. **Exception-only color.** A healthy, unstarred card = dark neutrals + teal only. Green = new/live event; coral = dead link / may-expire; amber = the user's star. Remove the colored type/verified/snapshot pill badges from the card face (demote to muted text). Tags are neutral.
4. **Fit is the right-aligned scan anchor**, tier-colored (≥85 teal, 70–84 neutral, <70 muted).
5. **Mobile/PWA must work.** Header reflows to two rows + a horizontal scrolling tab strip ≤640px; sticky header clears the notch/Dynamic Island via safe-area insets in standalone mode. Test by adding to Home Screen on iPhone Safari.
6. **Scope:** Opportunities tab + header + filters + PWA correctness only. Leave Pipeline, Map, Grow, Biography, Résumé visually unchanged and fully functional.
7. **Preserve all `localStorage` keys and the JSONBin sync payload shape.** Don't break cross-device sync.

**Work in small, reviewable commits**, in this order (the README's ship order):
1. Card `cardHTML()` + CSS + drawer/tag toggles.
2. Normalize accents to the oklch set; make color exception-only.
3. Compact left-aligned header + mobile reflow + safe-area insets + viewport meta.
4. Filter panel Refine/More split + segmented controls.
5. `sw.js` cache bump.

After each step, briefly tell me what changed and how to verify it. Before finishing, run through the **Acceptance criteria** checklist at the end of the README and report pass/fail on each. Ask me before doing anything outside the scope above (e.g. touching other tabs, changing the data model, or altering the sync format).
