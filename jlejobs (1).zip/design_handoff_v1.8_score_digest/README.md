# Design response — Score breakdown & Return digest (v1.8)

**For:** Claude Code
**From:** Claude Design
**Re:** the two presentation-only items in your `DESIGN-HANDOFF-v1.8.md`

Both designs are final. This is a **CSS swap + small template-string edit** for each — no scoring math, no digest computation, no data-flow changes. All values come from the variables you already expose (`sc.hitCore`, `sc.matched`, `sc.coverage`, `sc.disq`, `coreN`; digest `newCount`, `resurfacedThisVisit`, `watchedNew`, salary/skill movement). Same tokens, no new hues, exception-only color preserved.

**Visual source of truth:** `reference/Score & Digest v1.8.html` (open it). Screenshots in `screenshots/`. The reference's final section contains the exact drop-in CSS and template strings — they are reproduced below with the two refinements folded in.

---

## Item 1 — Score breakdown → "score anatomy"

**Where:** `cardHTML()` → the `breakdown` template, rendered in the Details drawer below "Why it fits".

**What changes (design intent):**
- Core coverage leads as a **literal segmented meter** — `coreN` segments, `sc.hitCore.length` filled teal. It's the honest fraction, readable at a glance instead of parsing "7/12 (58%)".
- **Drop the emoji** (🎯🧩). Use a quiet label-left / value-right rhythm matching the drawer's metadata grid.
- Résumé/bio matches becomes a soft secondary bar + count.
- The **disqualifier penalty stays a distinct coral inset row** (the one allowed color here, consistent with the card's alert strip) — only when `sc.disq`.
- "core hit" run → **neutral chips**. **[REFINEMENT — now included]** also render the *missing* core competencies as dashed muted chips, so the user sees what would raise the score.

### CSS — replace the `.rd-bd` / `.rd-bd-i` / `.rd-bd-core` block in `styles.css`:
```css
/* ITEM 1 — score anatomy */
.sa{display:flex;flex-direction:column;gap:11px;}
.sa-head{display:flex;align-items:baseline;justify-content:space-between;}
.sa-title{font-size:10px;text-transform:uppercase;letter-spacing:.8px;color:var(--text-mute);font-weight:700;}
.sa-score{font-size:13px;font-weight:800;color:var(--accent);font-variant-numeric:tabular-nums;}
.sa-score .of{color:var(--text-mute);font-weight:600;font-size:11px;}
.sa-row{display:flex;align-items:center;gap:11px;}
.sa-k{font-size:11.5px;color:var(--text-dim);flex:0 0 116px;}
.sa-meter{display:flex;gap:3px;flex:1;}
.sa-seg{height:7px;flex:1;border-radius:2px;background:var(--border);}
.sa-seg.on{background:var(--accent);}
.sa-v{font-size:11.5px;color:var(--text);font-weight:700;font-variant-numeric:tabular-nums;min-width:34px;text-align:right;}
.sa-v .pct{color:var(--text-mute);font-weight:600;}
.sa-bar2{flex:1;height:4px;border-radius:3px;background:var(--border);overflow:hidden;}
.sa-bar2 i{display:block;height:100%;background:var(--text-dim);border-radius:3px;}
.sa-disq{display:flex;align-items:center;gap:8px;font-size:11.5px;font-weight:600;color:var(--n-coral);
  background:rgba(255,123,114,.06);border:1px solid rgba(255,123,114,.2);border-radius:7px;padding:6px 10px;}
.sa-disq .x{font-weight:800;}
.sa-core{display:flex;flex-direction:column;gap:6px;}
.sa-core-l{font-size:10px;text-transform:uppercase;letter-spacing:.6px;color:var(--text-mute);font-weight:700;}
.sa-chips{display:flex;flex-wrap:wrap;gap:5px;}
.sa-chip{font-size:11px;color:var(--text-dim);background:transparent;border:1px solid var(--border);border-radius:var(--radius-sm);padding:1px 8px;}
.sa-chip.miss{color:var(--text-mute);border-style:dashed;opacity:.7;}
```

### Template — replace the `breakdown` const in `cardHTML()`:
```js
const matchPct = Math.min(100, Math.round(sc.matched.length / 20 * 100));
const segs = Array.from({length: coreN}, (_, i) =>
  `<span class="sa-seg${i < sc.hitCore.length ? ' on' : ''}"></span>`).join("");
// REFINEMENT: missing core competencies as dashed chips
const missCore = (CFG.CORE_COMPETENCIES || []).filter(c => !sc.hitCore.includes(c));
const coreChips =
  sc.hitCore.map(c => `<span class="sa-chip">${esc(c)}</span>`).join("") +
  missCore.map(c => `<span class="sa-chip miss">${esc(c)}</span>`).join("");
const breakdown = `
  <div class="sa">
    <div class="sa-head">
      <span class="sa-title">Why this score</span>
      <span class="sa-score">${pct}<span class="of"> / 100</span></span>
    </div>
    <div class="sa-row">
      <span class="sa-k">Core coverage</span>
      <div class="sa-meter">${segs}</div>
      <span class="sa-v">${sc.hitCore.length}/${coreN} <span class="pct">${Math.round(sc.coverage*100)}%</span></span>
    </div>
    <div class="sa-row">
      <span class="sa-k">Résumé &amp; bio matches</span>
      <div class="sa-bar2"><i style="width:${matchPct}%"></i></div>
      <span class="sa-v">${sc.matched.length}</span>
    </div>
    ${sc.disq ? `<div class="sa-disq"><span class="x">×${SC.DISQUALIFIER_PENALTY}</span> Disqualifier penalty applied — contains an excluded term</div>` : ""}
    ${(sc.hitCore.length || missCore.length) ? `<div class="sa-core"><span class="sa-core-l">Core competencies</span><div class="sa-chips">${coreChips}</div></div>` : ""}
  </div>`;
```
> If `coreN` is large (say > 20), the segmented meter gets thin — fall back to a single continuous `.sa-bar2`-style fill at that count, or cap segments at ~16 and show the rest as the numeric `x/N`. Your call; the fraction text always carries the exact value. The dashed "missing" chips can be dropped if the list runs long — they're the optional half of the refinement.

---

## Item 2 — Return digest → "Since you were away"

**Where:** `#digestBanner` container in `index.html` + `updateDigest()` in `app.js`.

**What changes (design intent):**
- **Kill the wall of green.** Remove the green left-border. Green now appears only as the "new" marker dot — so it's a signal, not a paint job.
- **Group by meaning.** *Activity counts* (new / resurfaced / watched-company) are what matter to the user — each on its own line with a colored marker dot (green / indigo / amber). *Market movement* (salary %, rising skill) collapses to one quiet footnote row under a divider.
- A clear **heading** ("Since you were away") frames it; Show/Dismiss become real `.rdg-btn` buttons (keep existing handlers).
- **[REFINEMENT — now included] Market-only state:** if there's no personal activity but there is market movement, still show the banner with heading **"Market update"** and just the market row (no empty activity group).

### CSS — replace the `.digest-banner` / `#digestText` / `.dg-line` block in `styles.css`:
```css
/* ITEM 2 — return digest */
.rdg{background:var(--surface);border:1px solid var(--border);border-radius:11px;padding:14px 16px 13px;margin-bottom:14px;}
.rdg-top{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:11px;}
.rdg-title{font-size:11px;text-transform:uppercase;letter-spacing:.9px;color:var(--text-dim);font-weight:700;display:flex;align-items:center;gap:8px;}
.rdg-title .since{color:var(--text-mute);}
.rdg-acts{display:flex;gap:6px;flex-shrink:0;}
.rdg-btn{background:transparent;border:1px solid var(--border);border-radius:var(--radius-sm);color:var(--text-dim);font-size:12px;font-weight:600;padding:5px 11px;cursor:pointer;}
.rdg-btn.primary{color:var(--accent);border-color:rgba(79,209,197,.4);}
.rdg-btn:hover{border-color:var(--border-2);}
.rdg-activity{display:flex;flex-direction:column;gap:8px;}
.rdg-line{display:flex;align-items:center;gap:10px;font-size:13px;color:var(--text-dim);}
.rdg-mk{width:7px;height:7px;border-radius:50%;flex-shrink:0;}
.rdg-mk.new{background:var(--n-green);} .rdg-mk.resurf{background:var(--n-indigo);} .rdg-mk.star{background:var(--n-amber);}
.rdg-line .n{color:var(--text);font-weight:800;font-variant-numeric:tabular-nums;}
.rdg-line .src{color:var(--text-mute);}
.rdg-market{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-top:11px;padding-top:11px;border-top:1px solid var(--border);font-size:12px;color:var(--text-mute);}
.rdg-market.solo{margin-top:0;padding-top:0;border-top:none;}  /* market-only state */
.rdg-market .ml{display:inline-flex;align-items:center;gap:5px;} .rdg-market .ml b{color:var(--text-dim);font-weight:700;}
.rdg-market .up{color:var(--n-green);} .rdg-market .down{color:var(--n-coral);} .rdg-market .sep{opacity:.4;}
.rdg-mlabel{font-size:9.5px;text-transform:uppercase;letter-spacing:.7px;color:var(--text-mute);font-weight:700;margin-right:4px;}
```

### `index.html` — give the banner the new shell:
```html
<div id="digestBanner" class="rdg" hidden>
  <div class="rdg-top">
    <span class="rdg-title" id="digestHeading">Since you were away</span>
    <span class="rdg-acts">
      <button class="rdg-btn primary" id="digestShow">Show new</button>
      <button class="rdg-btn" id="digestDismiss">Dismiss</button>
    </span>
  </div>
  <span id="digestText"></span>
</div>
```

### `updateDigest()` — build two groups instead of one `lines` array:
```js
const act = [], mkt = [];
if (newCount) act.push(`<div class="rdg-line"><span class="rdg-mk new"></span><span><span class="n">${newCount}</span> new since your last visit</span></div>`);
if (resurfacedThisVisit.size) act.push(`<div class="rdg-line"><span class="rdg-mk resurf"></span><span><span class="n">${resurfacedThisVisit.size}</span> snoozed role${resurfacedThisVisit.size>1?"s":""} resurfaced</span></div>`);
if (watchedNew.length) act.push(`<div class="rdg-line"><span class="rdg-mk star"></span><span><span class="n">${watchedNew.length}</span> new from compan${watchedNew.length>1?"ies":"y"} you star <span class="src">— ${esc([...new Set(watchedNew.map(j=>j.company))].slice(0,3).join(", "))}</span></span></div>`);
// market lines — keep your existing salary% / rising-skill conditionals, but push compact spans:
//   salary:  mkt.push(`<span class="ml">median salary <span class="${c>0?'up':'down'}">${c>0?'▲':'▼'} ${Math.abs(c)}%</span></span>`);
//   skill:   mkt.push(`<span class="ml"><b>“${esc(top.k)}”</b> rising in demand</span>`);
const solo = act.length === 0 && mkt.length > 0;           // REFINEMENT: market-only
const marketHTML = mkt.length
  ? `<div class="rdg-market${solo ? ' solo' : ''}">${solo ? '' : '<span class="rdg-mlabel">Market</span>'}${mkt.join('<span class="sep">·</span>')}</div>`
  : "";
if (visited && (act.length || mkt.length)) {
  document.getElementById("digestHeading").textContent = solo ? "Market update" : "Since you were away";
  document.getElementById("digestShow").style.display = solo ? "none" : "";   // nothing personal to "show"
  document.getElementById("digestText").innerHTML =
    `${act.length ? `<div class="rdg-activity">${act.join("")}</div>` : ""}${marketHTML}`;
  banner.hidden = false;
} else { banner.hidden = true; }
localStorage.setItem(LS.visited, "1");
```
> Keep the existing `#digestShow` / `#digestDismiss` click handlers — only the markup/classes changed. In the market-only state, "Show new" hides (there are no new cards to filter to); "Dismiss" stays.

---

## Files touched
| Item | `styles.css` | `app.js` | `index.html` |
|---|---|---|---|
| Score anatomy | replace `.rd-bd*` → `.sa*` block | `cardHTML()` → `breakdown` template | — |
| Return digest | replace `.digest-banner*` → `.rdg*` block | `updateDigest()` grouping | `#digestBanner` shell |

## Acceptance
- [ ] Drawer shows: "Why this score / N" header, a segmented coverage meter matching `hitCore/coreN`, a matches bar+count, optional coral penalty row, and core-competency chips (hit solid, missing dashed). No emoji.
- [ ] Penalty row appears only when `sc.disq` and reads as coral/problem.
- [ ] Digest has no green left-border; heading "Since you were away · N days"; activity lines with marker dots above a quiet "Market" footnote.
- [ ] Market-only return shows "Market update" with just the market row and no "Show new" button.
- [ ] Show/Dismiss still work; nothing in scoring or digest computation changed.

## Test the digest quickly
In DevTools: `localStorage.setItem('jle_visited','1')`, remove a couple ids from `jle_seen`, reload. For the market-only state, clear the personal counts (no new/resurfaced/watched) but ensure two months of market history exist.
