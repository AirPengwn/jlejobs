# Handoff: Opportunity Dashboard — card, header & filter redesign

## Overview
This package implements a visual-hierarchy redesign of the **Opportunities** tab of the `jlejobs` Opportunity Dashboard (a single-user, static, vanilla-JS PWA hosted on GitHub Pages). The goal is to reduce per-card density while **losing no information**, give the header a tool-like rhythm, make accent color meaningful instead of decorative, and make the whole thing behave correctly when installed as an iPhone PWA.

The core principle is a **three-tier volume system** applied everywhere:
- **Primary** — what the eye lands on first (title, Fit score)
- **Secondary** — supports the decision (company/location/salary, one "why it fits" line)
- **Ambient** — available but quiet until needed (skill tags, row actions, the full detail set)

Everything that used to sit at full volume on the card face (status dropdown, notes, draft-outreach, full description, full metadata grid, full tag list, apply/alt buttons) moves into a **collapsible "Details" drawer inside the card** — one tap away, never removed.

## About the Design Files
The file in `reference/Opportunity Dashboard Redesign.html` is a **design reference created in HTML** — a working prototype showing the intended look and the two expand interactions. It is **not** production code to copy wholesale.

**This is NOT a "port to a framework" task.** The target codebase is already vanilla HTML/CSS/JS with no build step. Your job is to **edit the existing files in place** — `assets/js/app.js`, `assets/css/styles.css`, `index.html`, and `sw.js` — matching the reference's appearance and behavior while wiring it to the **real** data (`window.JOBS`), the real fit logic (`fitPct()`), the real star/flag/hide/note/status handlers in `wireCards()`, JSONBin sync (`scheduleSync()`), and the existing detail modal.

Open the reference in a browser and click **"Details"** and the **"+N"** tag chips to see the two interactions before you start.

## Fidelity
**High-fidelity.** Colors, spacing, type sizes, radii, and the two interactions are final. Recreate them faithfully using the existing tokens in `:root` of `styles.css` (most already exist). Do not invent new colors beyond the normalized oklch accent set described below.

## Scope (do this, not more)
**In scope — the Opportunities tab only:**
1. The opportunity card (`cardHTML()` in `app.js` + `.card*` rules in `styles.css`)
2. The masthead/header (`index.html` `<header class="topbar">` + `.topbar/.masthead/.tabs` CSS) — compact, left-aligned, with a mobile/PWA reflow
3. The filter panel (`.filters-bar` markup + CSS) — split into always-visible "Refine" and a collapsible "More"
4. PWA/iOS correctness — safe-area insets, viewport, SW cache bump

**Out of scope for this pass (leave unchanged):** Pipeline, Map, Grow, Biography, Résumé tabs. They should keep working exactly as today. (A later pass unifies card/chart/radius/spacing across all tabs — note it, don't do it now.)

---

## Screen / View: Opportunities — card grid

### Layout
- Grid container `#cards.cards-grid`: `display:grid; grid-template-columns:repeat(auto-fill, minmax(312px,1fr)); gap:16px;` (currently `minmax(340px,1fr)` — tighten to 312).
- Each card is an `<article class="card">` (keep the class so existing `wireCards()` selectors still resolve), flex column, `gap:11px`, `padding:15px 16px 14px`, `border-radius:12px`, `background:var(--surface)` (flat — drop the current gradient + heavy shadow). `border:1px solid var(--border)`. On hover: `border-color:var(--border-2); transform:translateY(-2px)`.

### Card anatomy — COLLAPSED (default state)
Top → bottom:

1. **Kicker row** (`.r-kicker`, small): an optional **"New"** event marker (green dot + "New", only when `isNew(j)`), and a quiet uppercase **type label** ("Posting · verified", "Search · live", "Company · watch"). 10px, `letter-spacing:.8px`, `text-transform:uppercase`. Type label color `var(--text-mute)`; "New" uses `--n-green`; "live" uses `--n-green`. **No colored pill badges for type/verified/snapshot** — they become muted text.

2. **Title** (`.card-title`, keep class): 16.5px / weight 700 / `var(--text)`. `cursor:pointer`; clicking opens the existing detail modal (`openDetail(id)`). Hover → `var(--accent)`.

3. **Sub line** (`.r-sub`): `Company · Location · Salary`, 13px. Company in `var(--accent)` weight 600; salary in `var(--text)` weight 600; separators and location in `var(--text-dim)`. Abbreviate salary to compact form on the face (e.g. "$120–150k").

4. **Fit anchor** (`.r-fit`) — **right-aligned, top-right of the card, ~52px wide**, vertically aligned with the title block (use a flex row `.r-top` with `justify-content:space-between`). Contains:
   - `.r-fit-num`: the integer `fitPct(j)` (no "%"), 23px weight 800, tabular-nums.
   - `.r-fit-label`: "Fit", 9.5px uppercase `var(--text-mute)`.
   - `.r-fit-bar`: a 3px track with an inner `<i style="width:{pct}%">`.
   - **Tier coloring** (drives num + bar): `≥85` → teal (`.tier-hi`, `var(--accent)`); `70–84` → neutral (`.tier-mid`, `var(--text-dim)`); `<70` → muted (`.tier-lo`, `var(--text-mute)`). This makes Fit scannable straight down the column.

5. **"Why it fits"** (`.r-why`) — ONE line, 13px, `var(--text-dim)`, with a 2px `var(--accent-2)` left rule (a thin flex bar, not a filled box). Bold the lead phrase in `var(--accent)`. Source: `j.fit` (truncate to ~1.5 lines on the face; full text lives in the drawer).

6. **Tags** (`.r-tags`): show the first **3** `j.tags` as neutral chips (`.r-tag`: 11px, `var(--text-mute)`, transparent bg, `1px var(--border)`). If more exist, append a **`+N` toggle button** (`.r-tagmore`, teal text). Clicking reveals the hidden tags **in place** (toggle `.tags-open` on the card; hidden tags are `.r-tag.hid`, `display:none` until open) and flips the label to "− less". Tags are ambient — **never** colored semantically.

7. **Foot row** (`.r-foot`): space-between.
   - Left (`.r-foot-meta`): quiet meta, 12px `var(--text-mute)` — work mode and posted date (or "Live feed" / "6 openings" style short note). 
   - Right (`.r-foot-right`): a hover-revealed action cluster (`.r-actions`, `opacity:0` → 1 on card hover) containing **star / hide / open-link** as 30px icon buttons, PLUS an **always-visible "Details ⌄" toggle** (`.r-details`).

8. **Attention strip** (`.r-alert`) — appears **only** on an exception: `j.linkStatus === "dead"` → "⛔ Apply link returned 404 — try the alt link" (coral); `mayBeExpired(j)` / snapshot → "⚠ Snapshot — verify it's still live" (coral). `--n-coral`, subtle coral-tinted bg + border. A healthy card shows **no** alert.

### Card anatomy — EXPANDED ("Details" drawer, `.r-drawer`)
Toggling `.r-details` adds `.open` to the card and reveals `.r-drawer` (a `border-top` section that bleeds to the card edges: `margin:3px -16px -14px; padding:15px 16px; background:var(--bg-2); border-radius:0 0 12px 12px`). Drawer contains **everything currently on the card**, so no information is lost:
- **Full description** — untruncated `j.description`.
- **Why it fits** — full `j.fit` in the accent-bordered callout (`.rd-why`).
- **Metadata grid** (`.rd-grid`, 2-col): Location, Work mode, Commute (`commuteInfo(j)`), Salary (full string), Posted, Role family (`j.roleFamily.join(" · ")`), Source (`j.source`), Link check (`j.linkStatus` + `j.linkChecked`).
- **All skills** — every `j.tags` chip.
- **Controls** (`.rd-controls`): the status `<select>` (wire to existing status handler) + "✍ Draft outreach" button (wire to `openOutreach(id)`).
- **Note** — the notes `<textarea>` (wire to existing notes handler / `scheduleSync()`).
- **Foot** (`.rd-foot`): the apply (`j.applyUrl`) + alt (`j.altUrl`) buttons, reusing `.btn.primary`/`.btn.ghost`. For dead links, swap primary to "Try alt link" and show the dead-primary as a disabled coral ghost.

The toggle JS (mirror the reference):
```js
// after cards are rendered, in wireCards():
cards.querySelectorAll('.r-details').forEach(btn => {
  btn.addEventListener('click', e => {
    e.stopPropagation();
    const card = btn.closest('.card');
    const open = card.classList.toggle('open');
    btn.childNodes[0].nodeValue = open ? 'Hide ' : 'Details';
  });
});
cards.querySelectorAll('.r-tagmore').forEach(btn => {
  const n = btn.getAttribute('data-more');
  btn.addEventListener('click', e => {
    e.stopPropagation();
    const open = btn.closest('.card').classList.toggle('tags-open');
    btn.textContent = open ? '− less' : '+' + n;
  });
});
```
**Keep** the existing star/flag/hide/note/status/outreach wiring — just make sure the per-action click handlers call `e.stopPropagation()` so they don't bubble into the title/detail open.

> Optional product decision for the owner: the drawer and the existing full-screen detail modal now overlap. Recommended: keep **both** — drawer for an in-grid peek, modal (`openDetail`) for a focused full read via the title. Don't remove the modal.

---

## Screen / View: Header / masthead

### Desktop (≥ 641px)
Replace the centered, ~150px-tall stacked masthead with a **compact, left-aligned single bar (~58px)**:
- One flex row, `padding:11px 20px`, `gap:16px`, sticky, `background:rgba(13,17,23,.92)`, `backdrop-filter:blur(10px)`, `border-bottom:1px solid var(--border)`.
- **Left:** 34px circular avatar (`assets/img/stickman.jpg`, `1.5px var(--accent)` border) + brand block: title "Opportunity Dashboard" 15.5px/800 with the version as **tiny muted trivia** (`v1.5.1`, 10px `var(--text-mute)`, inline) and a 11.5px `var(--text-mute)` subtitle "John L. Evans · Connecticut & Remote".
- **Tabs:** left-aligned, `margin-left:8px`, text buttons (no boxes); active tab = `var(--accent)` text with a 2px teal underline. Tap target ≥ 36px tall on desktop.
- **Right (`margin-left:auto`):** sync status as a small chip ("● Sync off"), `var(--text-mute)`, bordered. Not centered, not a headline.

### Mobile / PWA (≤ 640px) — REQUIRED, this is where the current design breaks
The single row cannot hold brand + 6 tabs + sync on a ~390px phone, and in standalone PWA mode the sticky bar slides under the notch / Dynamic Island. Reflow to **two rows + safe areas**:
- **Row 1:** avatar (28px) + brand (title 13.5px, ellipsis; sub "John L. Evans · v1.5.1") + a single **☁ sync icon button** (34px) pushed right.
- **Row 2:** the 6 tabs as a **horizontal scroll strip** of pills — `overflow-x:auto; -webkit-overflow-scrolling:touch; scrollbar-width:none; gap:6px`, each pill `flex-shrink:0`, `white-space:nowrap`, padding `7px 14px`, ≥ 44px effective tap target. Active pill = filled teal. Add a right-edge fade hint (`linear-gradient(90deg,transparent,var(--bg))`) so users know it scrolls.
- See `.mh*` / `.phone*` classes in the reference for the exact mobile markup/CSS.

---

## Screen / View: Filter panel

Split the flat 7-section `.filters-bar` into a fast path + Refine + collapsible More:
- **Line 1:** search input (flex) + the quick-**view** chips (New / Starred / Flagged / Hidden) on the right. These are saved views — keep them always visible as the fast path.
- **Refine row** (`.rf-refine`, always visible): the 3–4 filters a CT-based passive watcher actually touches — **Location** (chips), **Work mode** (segmented control `.seg`), **Minimum fit** (segmented: Any / 50+ / 70+ / 85+), **Min salary** (compact slider + teal readout). At the end, a dashed **"＋ More filters ▾"** button.
- **More (collapsed by default):** Role family, Skills / keywords, Card type, My status — the occasional controls. Reveal on clicking "More filters".
- **Presets row** stays below.
- Convert Work mode and Card type to the same segmented-pill pattern as Min fit for consistency.

---

## Interactions & Behavior
- **Card title click** → `openDetail(j.id)` (existing modal). Keep.
- **"Details" toggle** → expand/collapse `.r-drawer` in place; label flips Details ⇄ Hide.
- **"+N" tag toggle** → reveal/hide overflow tags in place; label flips +N ⇄ − less.
- **Star / Hide / Note / Status / Outreach** → unchanged behavior; ensure `stopPropagation`. Star sets amber border (`.starred`/existing `.on`), hide dims/removes per current logic, note + status persist via `scheduleSync()`.
- **More filters** → toggle visibility of the advanced filter groups.
- **Tabs scroll strip** (mobile) → native horizontal scroll; no JS needed beyond the fade.
- Transitions: card hover `border-color/transform .15s`; chevron rotate `.2s`; drawer simple show/hide (optionally animate `max-height`).

## State Management
No new global state required. Expand/collapse is per-card DOM state (`.open`, `.tags-open`) and resets on `render()` (acceptable — re-rendering recollapses cards). All persisted state (starred/flagged/hidden/notes/status, watchlist, presets) keeps using the existing `localStorage` keys (`LS.*`) and `scheduleSync()` JSONBin flow. **Do not** change the sync payload shape.

## Design Tokens

### Existing (keep — already in `:root`)
```
--bg:#0d1117  --bg-2:#0f151d  --surface:#161c26  --surface-2:#1b2330
--border:#263041  --border-2:#324056
--text:#e6edf3  --text-dim:#9aa7b8  --text-mute:#6b7888
--accent:#4fd1c5  --accent-2:#3aa99e  --accent-ink:#062b28
--star:#f5c451  --flag:#ff7b72  --new:#3fb950  --indigo:#7c8cff
--radius:14px  (introduce a second --radius-sm:8px for chips/buttons; use 12px for cards)
```

### New — normalized accent family (add to `:root`)
Normalize the semantic accents to one oklch lightness/chroma (vary hue only) so they read as one family and stop vibrating against the dark surface. Use these for the **exception-only** signals:
```
--n-teal:  oklch(0.78 0.11 185);
--n-green: oklch(0.78 0.11 150);   /* "new" / "live" events */
--n-amber: oklch(0.78 0.11 85);    /* user star, only when set */
--n-coral: oklch(0.78 0.11 30);    /* problems: dead link / may-expire */
--n-indigo:oklch(0.78 0.11 275);
```
**Color policy:** teal = interactive + Fit ≥ 85; green = an event; coral = a problem; amber = the user's star. A healthy, unstarred card is **dark neutrals + teal only**. Tags are neutral. Remove the colored type/verified/snapshot pill badges from the card face.

### Spacing & radius
- Card radius **12**; chips/buttons radius **8**. Pick ONE of each — don't use the 10–14px range.
- Use an 8px spacing scale (8 / 16 / 24) for gaps and padding going forward.

## PWA / iOS correctness (required)
1. **Viewport:** change `index.html` meta to `width=device-width, initial-scale=1.0, viewport-fit=cover`.
2. **Safe areas:** pad the sticky header top with `env(safe-area-inset-top)` (and respect `safe-area-inset-left/right` on the rows) so it clears the notch / Dynamic Island in standalone mode. Add a small bottom inset on the footer if needed.
3. **Tabs** must be the horizontal scroll strip below 640px (above).
4. **Already correct — don't change:** `theme-color #0d1117` (matches the bar) and `apple-touch-icon`.
5. **Service worker:** in `sw.js`, **bump the cache name/version** (e.g. `jle-cache-v1.5.2`) and ensure old caches are deleted in `activate`, so the restyled `styles.css` / `app.js` actually ship to installed clients without a hard refresh. (The owner has hit stale-stylesheet caching before — this is the fix.)

## Assets
- `assets/img/stickman.jpg` — existing avatar, reused at 34px (desktop) / 28px (mobile). No new assets.

## Files to edit
- `index.html` — viewport meta; header/masthead markup; filter panel markup (Refine/More).
- `assets/css/styles.css` — `:root` additions; card rules; header rules + `@media (max-width:640px)` reflow + safe-area insets; filter rules; segmented control `.seg`.
- `assets/js/app.js` — `cardHTML()` rewrite (collapsed face + `.r-drawer`); add `.r-details` / `.r-tagmore` listeners in `wireCards()`; ensure action handlers `stopPropagation`; filter-panel "More" toggle. Keep `fitPct`, `commuteInfo`, `isNew`, `mayBeExpired`, sort/filter, sync untouched.
- `sw.js` — bump cache version + clean old caches.

## Reference
- `reference/Opportunity Dashboard Redesign.html` — the hifi prototype. Sections: 01 card before/after, 02 calm grid (6 real cards, expandable Details + tags), 03 header before/after, 03b iPhone/PWA mock + checklist, 04 filters before/after, 05 ship order. Open it and exercise the "Details" and "+N" toggles.

## Acceptance criteria
- [ ] A healthy card shows only: kicker (optional New), title, sub, Fit anchor, one why-line, ≤3 tags + optional +N, quiet foot. No colored type badges. ~190px tall.
- [ ] "Details" reveals full description, why, full metadata grid, all tags, status, note, outreach, apply/alt — **nothing from the old card is missing**.
- [ ] "+N" expands/collapses overflow tags in place.
- [ ] Fit is right-aligned and tier-colored; scannable down the column.
- [ ] Color appears only on events (new/live), problems (dead/expire), the user's star, and interactive elements. Verified on a full grid of real `JOBS`.
- [ ] Header is compact + left-aligned on desktop; two-row with a scrolling tab strip on mobile; clears the notch in an installed iPhone PWA (test in Safari → Add to Home Screen).
- [ ] Filters: search + view chips + Refine visible; Role family/Skills/Card type/Status behind "More".
- [ ] Pipeline / Map / Grow / Bio / Résumé tabs unchanged and still functional.
- [ ] SW cache bumped; new styles load on an installed client without a manual hard refresh.
- [ ] Star/flag/hide/note/status persist and still sync via JSONBin.
