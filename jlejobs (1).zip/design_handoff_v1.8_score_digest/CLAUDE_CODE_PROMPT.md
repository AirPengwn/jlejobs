# Claude Code prompt — Score breakdown & Return digest (v1.8)

Paste everything below the line into Claude Code, running in the `jlejobs` repo with this `design_handoff_v1.8_score_digest/` folder present.

---

In the `jlejobs` repo, implement the two design-response items in `design_handoff_v1.8_score_digest/README.md` — the score breakdown and return digest you flagged for Design in `DESIGN-HANDOFF-v1.8.md`. Read that README in full; the visual source of truth is `reference/Score & Digest v1.8.html` (open it) with `screenshots/` for quick reference.

These are **presentation-only**. Do NOT change the scoring math, the digest computation, or the data flow. You're swapping CSS blocks and re-rendering existing variables (`sc.hitCore`, `sc.matched`, `sc.coverage`, `sc.disq`, `coreN`; digest `newCount`, `resurfacedThisVisit`, `watchedNew`, salary/skill movement) into new markup. The README gives the exact CSS and template strings — use them; don't improvise new colors or hues (exception-only color policy stays).

**Item 1 — score anatomy** (`cardHTML()` `breakdown` template + `.rd-bd*` CSS in `styles.css`):
- Core coverage as a segmented meter (`coreN` segments, `sc.hitCore.length` filled).
- Drop emoji; label-left/value-right rhythm matching the metadata grid.
- Matches as a soft bar + count.
- Disqualifier penalty = coral inset row, only when `sc.disq`.
- Core competencies as chips: hit = solid, **missing = dashed muted** (the included refinement). If the core list is long (>~20), fall back per the README note.

**Item 2 — return digest** (`#digestBanner` in `index.html` + `updateDigest()` + `.digest-banner*` CSS):
- Remove the green left-border; group activity counts (marker dots: green/indigo/amber) above a quiet "Market" footnote.
- Heading "Since you were away · N days"; Show/Dismiss become `.rdg-btn` buttons keeping their existing handlers.
- **Market-only state** (the included refinement): no personal activity but market movement → heading "Market update", market row only, hide "Show new".

Work in two small commits (Item 1, then Item 2). After each, tell me what changed and how to verify it (the README has a DevTools recipe for forcing the digest). Then run the README's acceptance checklist and report pass/fail per line. Ask me before touching anything outside these two items (scoring, other tabs, data model, sync).
