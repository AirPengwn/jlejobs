# Screenshots

Target renders from `reference/Opportunity Dashboard Redesign.html` (open it to exercise the live "Details" and "+N" toggles).

| File | Shows |
|------|-------|
| `01-card-before-after.png` | The opportunity card — current (left) vs redesigned collapsed (right) |
| `02-calm-grid.png` | Six real cards in the redesigned grid; color firing only on events/problems |
| `03-header-before-after.png` | Centered ~150px masthead vs compact left-aligned ~58px bar |
| `04-iphone-pwa.png` | 390px standalone-PWA mock (reflowed header + scroll tabs) + the PWA checklist |
| `05-filters-before-after.png` | Flat 7-section panel vs fast-path + Refine + collapsible More |
| `06-card-expanded-detail.png` | The redesigned card with its **Details** drawer open — every field preserved |
