# Screenshots

Target renders from `reference/Score & Digest v1.8.html`.

| File | Shows |
|------|-------|
| `01-score-before-after.png` | Score breakdown — current emoji+text run vs the redesigned "score anatomy" with coverage meter |
| `02-score-disqualifier.png` | The disqualifier-penalty state (coral inset row) |
| `03-digest-before-after.png` | Return digest — current green-bordered 5-line banner vs grouped "Since you were away" |
